﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tuition_Management_System
{
    public partial class Courses : Form
    {
        int id;
        public Courses()
        {
            InitializeComponent();
        }
        DataClasses1DataContext dc = new DataClasses1DataContext();
        private void button3_Click(object sender, EventArgs e)
        {
            Form2 F2 = new Form2();
            F2.Show();
            this.Hide();
        }
        private void button2_Click(object sender, EventArgs e)
        {
          
        }
        private void button1_Click(object sender, EventArgs e)
        {
            var a = (from s in dc.Classes select new { s.Class1, s.Subject });
            try { 
            var a1 = (from st in dc.Staffs
                      select new { st.Name });
            dataGridView1.DataSource = a;
            DataGridViewComboBoxColumn dcom = new DataGridViewComboBoxColumn();
            dcom.HeaderText = "Select Teacher";
            dcom.DataSource = a1;
            dataGridView1.Columns.Add(dcom);
                }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int x = dataGridView1.SelectedCells[0].RowIndex;
            DataGridViewRow selRow = dataGridView1.Rows[x];
            id = Convert.ToInt32(selRow.Cells[0].Value);
        }

        private void Courses_Load(object sender, EventArgs e)
        {

        }
    }
}
