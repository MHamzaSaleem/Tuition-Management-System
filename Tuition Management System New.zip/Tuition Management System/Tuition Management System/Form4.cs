﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Tuition_Management_System
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        DataClasses1DataContext dx = new DataClasses1DataContext();
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=VPL_PROJECT;Integrated Security=True");
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(textBox1.Text);
                con.Open();
                string q = " select  s.Name,f.Fees,f.Status,f.Date_Of_Submission  from Student s , Fee f where s.Stu_ID=f.Stu_ID And f.Stu_ID='"+textBox1.Text+"'";
                SqlCommand com = new SqlCommand(q, con);
                com.CommandType = CommandType.Text;
                DataTable st = new DataTable();
                st.Load(com.ExecuteReader());
   dataGridView1.DataSource = st;
       
            }
        catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 F2 = new Form2();
            F2.Show();
            this.Hide();
        }

    }
}
