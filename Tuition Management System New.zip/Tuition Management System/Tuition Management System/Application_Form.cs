﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Tuition_Management_System
{
    public partial class Application_Form : Form
    {
        public Application_Form()
        {
            InitializeComponent();
        } 
        DataClasses1DataContext dx1 = new DataClasses1DataContext();
        DataClasses1DataContext dx = new DataClasses1DataContext();
        private static int id;
        private void button2_Click(object sender, EventArgs e)
        {
            panel1.Show();
            dataGridView2.Hide();
            panel2.Hide();
            dataGridView1.Hide();
        }
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=VPL_PROJECT;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            panel2.Hide();
            panel1.Hide();
            dataGridView2.Hide();
            dataGridView1.Show();
            try
            {
                string sql = "select s.Name,s.Address,s.Phone,s.Email,t.Experience,t.Salary,t.Subject from Teacher t, Staff s where s.S_ID=t.S_ID";
                SqlDataAdapter adp = new SqlDataAdapter(sql, con);
                DataSet ds = new DataSet();
                con.Open();
              //  MessageBox.Show("1");
               
                adp.Fill(ds, "Authors_table");
              //  MessageBox.Show("2");
                con.Close();
                dataGridView1.DataSource = ds;
              //  MessageBox.Show("3");

                dataGridView1.DataMember = "Authors_table";
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

   

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int x = dataGridView1.SelectedCells[0].RowIndex;
                DataGridViewRow selRow = dataGridView1.Rows[x];
                id = Convert.ToInt32(selRow.Cells[0].Value);
                string a = id.ToString(); MessageBox.Show(a);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel2.Hide();
            //dataGridView1.Hide();
            panel1.Show();
            try
            {
                string Query = "insert into Staff values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')";
                string Query1 = "insert into Teacher values(@@Identity,'"+textBox5.Text+"','" + textBox6.Text + "','"+textBox7.Text+"')";
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                cmd.ExecuteNonQuery();
                SqlCommand cmd1 = new SqlCommand(Query1, con);
                cmd1.ExecuteNonQuery();
                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = textBox5.Text = textBox7.Text= "";
                MessageBox.Show("Inserted!");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int x = dataGridView2.SelectedCells[0].RowIndex;
             //   MessageBox.Show("1");
                DataGridViewRow selRow = dataGridView2.Rows[x];
             //   MessageBox.Show("2");
                id = Convert.ToInt32(selRow.Cells[0].Value);
             //   MessageBox.Show("3");
                string a = id.ToString(); MessageBox.Show(a);
         
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            dataGridView1.Hide();
            dataGridView2.Show();
            panel2.Show();
            DataGrid2();
        }

        private void DataGrid2()
        {
            try
            {
                string sql = "select s.S_ID, s.Name,s.Address,s.Phone,s.Email,t.Experience,t.Salary,t.Subject from Teacher t, Staff s where s.S_ID=t.S_ID";
                SqlDataAdapter adp = new SqlDataAdapter(sql, con);
                DataSet ds = new DataSet();
                con.Open();
                //  MessageBox.Show("1");

                adp.Fill(ds, "Authors_table");
                //  MessageBox.Show("2");
                con.Close();
                dataGridView2.DataSource = ds;

                //  MessageBox.Show("3");
                dataGridView2.DataMember = "Authors_table";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Updation();
            DataGrid2();
        }

        private void Updation()
        {
            try
            {
                string a = id.ToString();
                MessageBox.Show(a);
                string Q = "UPDATE dbo.Staff  SET Name = '" + textBox14.Text + "', Email='" + textBox11.Text + "',Phone='" + textBox12.Text + "',Address='" + textBox13.Text + "'  WHERE S_ID = '" + id + "'";
                string Q1 = "UPDATE dbo.Teacher  SET Experience = '" + textBox9.Text + "',Subject='" + textBox10.Text + "',Salary = '" + textBox8.Text + "'  WHERE S_ID = '" + id + "'";
                con.Open();
                SqlCommand cmd = new SqlCommand(Q, con);
                cmd.ExecuteNonQuery();
                SqlCommand cmd1 = new SqlCommand(Q1, con);
                cmd1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Updated");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Form2 F2 = new Form2();
            F2.Show();
            this.Hide();
        }

        private void Application_Form_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}