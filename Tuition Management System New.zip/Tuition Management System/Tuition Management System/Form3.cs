﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace Tuition_Management_System
{
    public partial class Form3 : Form
    {
        private static int id;
        public Form3()
        {
            InitializeComponent();
        }
        DataClasses1DataContext dx = new DataClasses1DataContext();
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=VPL_PROJECT;Integrated Security=True");
        private void Form3_Load(object sender, EventArgs e)
        {
            panel1.Hide();
        //    try
        //    {
        //        string Query = "select * from Student where class='9'";
        //        SqlCommand com = new SqlCommand(Query, con);
        //    }
        //    catch(Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
         //   var q = (from s in dx.Students
          //          where s.Class == "9"
           //          select new {s.Name,s.Address,s.Phone,s.Age });
           
            // select Distinct f.Fees from Fee f , Student s where s.Class='9'
        }

        private void Form3_Load_1(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            dataGridView3.Hide();
            button6.Hide();
            button11.Hide();
            panel2.Hide();
            panel4.Hide();
            panel1.Show();
            GetData();
        }

        private void GetData()
        {
            var q = from s in dx.Students
                    join f in dx.Fees on s.Stu_ID equals f.Stu_ID
                    where s.Class == "9"
                    select new { s.Stu_ID, s.Name, s.Age, s.Address, s.Phone, f.Fees };
            dataGridView1.DataSource = q;
        }

       
            
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string a = id.ToString();
                MessageBox.Show(a);
                string Q = "UPDATE dbo.Student  SET Name = '" + textBox10.Text + "', Age='" + textBox7.Text + "',Phone='" + textBox8.Text + "',Address='" + textBox9.Text + "'  WHERE Stu_ID = '" + id + "'";
                string Q1 = "UPDATE dbo.Fee  SET Fees = '" + textBox6.Text + "'  WHERE Stu_ID = '" + id + "'";
                con.Open();
                SqlCommand cmd = new SqlCommand(Q, con);
                cmd.ExecuteNonQuery();
                SqlCommand cmd1 = new SqlCommand(Q1, con);
                cmd1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Updated");
                GetData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            //Student1 s = dx.Students.Single(i=>i.Stu_ID == Stu_ID);
            //s.Name = textBox1.Text;
            //s.email = textBox2.Text;

            //dx.SubmitChanges();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Class10();
        }

        private void Class10()
        {
            dataGridView3.Hide();
            button6.Hide();
            button11.Hide();
            panel1.Hide();
            panel4.Hide();
            panel2.Show();
            var q = from s in dx.Students
                    join f in dx.Fees on s.Stu_ID equals f.Stu_ID
                    where s.Class == "10"
                    select new { s.Stu_ID, s.Name, s.Age, s.Address, s.Phone, f.Fees };
            dataGridView2.DataSource = q;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            panel1.Hide();
            panel4.Hide();
            panel2.Hide();
            dataGridView3.Show();
            button6.Show();
            button11.Show();
            var q = from s in dx.Students
                    join f in dx.Fees on s.Stu_ID equals f.Stu_ID
                    where s.Class == "11"
                    select new { s.Stu_ID, s.Name, s.Age, s.Address, s.Phone, f.Fees };
            dataGridView3.DataSource = q;
        
           
        }

        private void button10_Click(object sender, EventArgs e)
        {
            dataGridView3.Hide();
            button6.Hide();
            button11.Hide(); 
            panel2.Hide();
            panel1.Hide();
            panel4.Show();
            var q = from s in dx.Students
                    join f in dx.Fees on s.Stu_ID equals f.Stu_ID
                    where s.Class == "12"
                    select new { s.Stu_ID, s.Name, s.Age, s.Address, s.Phone, f.Fees };
            dataGridView4.DataSource = q;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
            Form2 F2 = new Form2();
            F2.Show();
            this.Hide();
              }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            try
            { 
            Student s = dx.Students.Single(i => i.Stu_ID == id);
            s.Name = textBox1.Text;
            s.Address = textBox2.Text;
            s.Class = 12.ToString();
            s.Age = Convert.ToInt16(textBox4.Text);
            s.Phone = textBox3.Text;
            s.AddedBy = 1;
                MessageBox.Show("done");
            //Fee f = dx.Fees.Single(j => j.Stu_ID == id);
            //f.Fees = Convert.ToInt16(textBox5.Text);
            dx.SubmitChanges();

        }
        catch(Exception ex)
    {
        MessageBox.Show(ex.Message);
    }

        }
        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int x = dataGridView4.SelectedCells[0].RowIndex;
            DataGridViewRow selRow = dataGridView4.Rows[x];
            id = Convert.ToInt32(selRow.Cells[0].Value);

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            int x = dataGridView1.SelectedCells[0].RowIndex;
            DataGridViewRow selRow = dataGridView1.Rows[x];
            id = Convert.ToInt32(selRow.Cells[0].Value);
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int x = dataGridView2.SelectedCells[0].RowIndex;
            DataGridViewRow selRow = dataGridView2.Rows[x];
            id = Convert.ToInt32(selRow.Cells[0].Value);
            string a = id.ToString(); MessageBox.Show(a);
        }
       

        private void button4_Click(object sender, EventArgs e)
        {
         try
         {
             string a = id.ToString();
             MessageBox.Show(a);
             string Q = "UPDATE dbo.Student  SET Name = '" + textBox1.Text + "', Age='" + textBox4.Text + "',Phone='" + textBox3.Text + "',Address='" + textBox2.Text + "'  WHERE Stu_ID = '" + id + "'";
             string Q1 = "UPDATE dbo.Fee  SET Fees = '" + textBox5.Text + "'  WHERE Stu_ID = '" + id + "'";
             con.Open();
           SqlCommand cmd = new SqlCommand(Q, con);
           cmd.ExecuteNonQuery();
           SqlCommand cmd1 = new SqlCommand(Q1, con);
           cmd1.ExecuteNonQuery();
           con.Close();
             MessageBox.Show("Updated");
             Class10() ;
          }
         catch(Exception ex)
         {
            MessageBox.Show(ex.Message);
         }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            { 
            string a2 = id.ToString();
            MessageBox.Show(a2);
            var a = dx.Students.First(s => s.Stu_ID == id);
            dx.Students.DeleteOnSubmit(a);
           
            var a1 = dx.Fees.First(s => s.Stu_ID == id);
            dx.Fees.DeleteOnSubmit(a1);
            dx.SubmitChanges();
            Class10();
        }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
        {
            int x = dataGridView1.SelectedCells[0].RowIndex;
            DataGridViewRow selRow = dataGridView1.Rows[x];
            id = Convert.ToInt32(selRow.Cells[0].Value);
            string a = id.ToString(); MessageBox.Show(a);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string a = id.ToString();
                MessageBox.Show(a);
                string Q1 = "DELETE FROM Fee WHERE Stu_ID='" + id + "'";
                string Q = "DELETE FROM Student WHERE Stu_ID='"+id+"'";
              
                con.Open();
                SqlCommand cmd = new SqlCommand(Q1, con);
                cmd.ExecuteNonQuery();
                SqlCommand cmd1 = new SqlCommand(Q, con);
                cmd1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Deleted");
                Class10();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            try
            {
                string a = id.ToString();
                MessageBox.Show(a);
                string Q1 = "DELETE FROM Fee WHERE Stu_ID='" + id + "'";
                string Q = "DELETE FROM Student WHERE Stu_ID='" + id + "'";

                con.Open();
                SqlCommand cmd = new SqlCommand(Q1, con);
                cmd.ExecuteNonQuery();
                SqlCommand cmd1 = new SqlCommand(Q, con);
                cmd1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Deleted");
                Class10();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            try
            {
                string a = id.ToString();
                MessageBox.Show(a);
                string Q = "UPDATE dbo.Student  SET Name = '" + textBox5.Text + "', Age='" + textBox2.Text + "',Phone='" + textBox3.Text + "',Address='" + textBox4.Text + "'  WHERE Stu_ID = '" + id + "'";
                string Q1 = "UPDATE dbo.Fee  SET Fees = '" + textBox1.Text + "'  WHERE Stu_ID = '" + id + "'";
                con.Open();
                SqlCommand cmd = new SqlCommand(Q, con);
                cmd.ExecuteNonQuery();
                SqlCommand cmd1 = new SqlCommand(Q1, con);
                cmd1.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Updated");
                Class10();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

       
           
    }
}
