﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
 

namespace Tuition_Management_System
{


    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
      
        }
        public static string u ;
        public static int a=1;
        private void Form1_Load(object sender, EventArgs e)
        {
      
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (IsvalidUser(textBox1.Text, textBox2.Text))
            {
             Form2 F2 = new Form2();
                F2.Show();
                this.Hide();
            }
        }
        private bool IsvalidUser(string userName, string password)
        {



            DataClasses1DataContext context = new DataClasses1DataContext();

            var q = from p in context.Staff_Account_Informations

                    where p.UserName == textBox1.Text

                    && p.Password == textBox2.Text
                    select p ;
            a++;
            u = textBox1.Text;
            
            if (q.Any())
            {
                MessageBox.Show("Welcome");
                return true;

            }

            else
            {
                MessageBox.Show("Try Again User And PAssword is Incorret");
                return false;

            }

        }
    }
}
