﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Tuition_Management_System
{
    public partial class Form2 : Form
    {
        string b = Form1.u;
        int a = 1;
        public Form2()
        {
           
                InitializeComponent();
        }
        DataClasses1DataContext dx = new DataClasses1DataContext();
        private void Form2_Load(object sender, EventArgs e)
        {
            
        }

        


      
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=VPL_PROJECT;Integrated Security=True");
        private void button5_Click(object sender, EventArgs e)
        {
            Form1 F1 = new Form1();
            F1.Show();
            this.Hide();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            label1.Show();
            label2.Show();
            label3.Show();
            label4.Show();
            label5.Show();
            label6.Show();
            textBox1.Show();
            textBox2.Show();
            textBox3.Show();
            textBox4.Show();
            textBox5.Show();
            textBox6.Show();
            button6.Show(); 
            panel2.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            try
            {
                var dt = DateTime.Now;
                string formattedTime = dt.ToString("yyyy, MM, dd, hh, mm, ss");
                string Query = "insert into Student values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox3.Text + "','"+a+"')";
                string Query1 = "insert into Fee values(@@Identity,'" + textBox6.Text + "','Paid', '" + DateTime.Now + "')";
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                cmd.ExecuteNonQuery();
                SqlCommand cmd1 = new SqlCommand(Query1, con);
                cmd1.ExecuteNonQuery();
                textBox1.Text = textBox2.Text = "";
                MessageBox.Show("Registered!");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application_Form af = new Application_Form();
            af.Show();
            this.Hide();
            //panel2.Show();
            //dataGridView1.Show();
            //var q = from t in dx.Staffs select t;
            //dataGridView1.DataSource = q;
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form2_Load_1(object sender, EventArgs e)
        {
            try
            {
                label7.Text = "Logged In As A " + Form1.u;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //label1.Hide();
            //label2.Hide();
            //label3.Hide();
            //label4.Hide();
            //label5.Hide();
            //label6.Hide();
            //textBox1.Hide();
            //textBox2.Hide();
            //textBox3.Hide();
            //textBox4.Hide();
            //textBox5.Hide();
            //textBox6.Hide();
            //button6.Hide();
            //panel2.Hide();
            //dataGridView1.Hide();
            //panel1.Show();
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();
            
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            { 
            Form3 F3 = new Form3();
            F3.Show();
            this.Hide();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Hide();
            label2.Hide();
            label3.Hide();
            label4.Hide();
            label5.Hide();
            label6.Hide();
            textBox1.Hide();
            textBox2.Hide();
            textBox3.Hide();
            textBox4.Hide();
            textBox5.Hide();
            textBox6.Hide();
            button6.Hide();
            panel2.Show();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            Courses C = new Courses();
            C.Show();
            this.Hide();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(textBox9.Text);
                string Query = "insert into Fee values('" + a + "','" + textBox10.Text + "','"+comboBox1.Text+"','" + DateTime.Now + "')";
                con.Open();
                SqlCommand cmd = new SqlCommand(Query, con);
                cmd.ExecuteNonQuery();
                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = textBox5.Text = textBox5.Text = textBox7.Text = "";
                MessageBox.Show("Inserted!");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            Form4 F4 = new Form4();
            F4.Show();
            this.Hide();
        }

    }
}
