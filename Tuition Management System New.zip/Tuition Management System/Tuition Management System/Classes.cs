﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tuition_Management_System
{
    public partial class Classes : Form
    {
        public Classes()
        {
            InitializeComponent();
        }
        DataClasses1DataContext dx = new DataClasses1DataContext();

        private void button7_Click(object sender, EventArgs e)
        {
            GetData();
        }
              private void GetData()
        {
            var q = from s in dx.Students
                    join f in dx.Fees on s.Stu_ID equals f.Stu_ID
                    where s.Class == "9"
                    select new { s.Stu_ID, s.Name, s.Age, s.Address, s.Phone, f.Fees };
            dataGridView1.DataSource = q;
        }
        

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
             try
            {
            Form2 F2 = new Form2();
            F2.Show();
            this.Hide();
              }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Classes_Load(object sender, EventArgs e)
        {

        }
    }
}
